class Networks {

    // ––––––––– TODO: Get JSON data from internet
    static getJSON(callback) {

    }


    // ––––––––– TODO: Retrieve all pokemon data and add to HTML
    static fetchAllPokemon() {
        return
    }

    // ––––––––– TODO: Fetch specific pokemon that was selected and display
    //                 it's information
    static fetchPokemonDetails(pokemonId) {
        return 
    }
}


// After Data has been loaded, stop showing the loading animation
function hideLoading() {
    let loading = document.getElementsByClassName('loading')[0];
    loading.classList.add('hide-loading');
}
