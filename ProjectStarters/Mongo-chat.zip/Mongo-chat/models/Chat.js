// STEP 2: Build Chat schema
