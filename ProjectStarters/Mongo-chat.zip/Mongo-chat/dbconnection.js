// STEP 1: Initialize connection to database
// Database Connection
