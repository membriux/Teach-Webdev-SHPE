
// STEP 2: Build Item Schema
